define(["models/pl/requestPolicyModel"], function () {

    function fromPartyToJS(partyObj) {
        
    }

    function fromJSToParty(jsObj) {
        
    }

    return {
        fromJSToParty: fromJSToParty,
        fromPartyToJS: fromPartyToJS
    }

});