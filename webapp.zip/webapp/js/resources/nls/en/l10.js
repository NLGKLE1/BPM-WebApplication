define({
  'homepage-welcome': 'Welcome En, '
  });