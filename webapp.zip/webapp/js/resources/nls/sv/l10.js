define({
    'homepage-welcome': 'Welcome SV, '
  });