define({
    'homepage-welcome': 'Welcome FR, '
  });