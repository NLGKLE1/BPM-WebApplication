define({
    'homepage-welcome': 'Welcome NO, '
  });