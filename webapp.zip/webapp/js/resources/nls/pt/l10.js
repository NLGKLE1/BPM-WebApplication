define({
    //Homepage
    'homepage-welcome': 'Bem vindo, ',
  });