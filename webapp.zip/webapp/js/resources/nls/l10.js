define({
  'root': {
    //Homepage
    'homepage-welcome': 'Welcome, ',
    //login
    'login-titlelogin': 'Login',
    'login-userLabel': 'Username:',
    'login-pwLabel': 'Password:',
    'login-loginButtonText': 'LOGIN',

    //button text
    'accept-buttonText': 'Accept',
    'correct-buttonText': 'Corrected'
  },

  'da': true,
  'de': true,
  'en': true,
  'es': true,
  'fi': true,
  'fr': true,
  'it': true,
  'nl': true,
  'no': true,
  'pt': true,
  'sv': true
});
