define({
 
    //Homepage
    'homepage-welcome': 'Welcom It,',

  
});