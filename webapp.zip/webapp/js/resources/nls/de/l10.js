define({
    'homepage-welcome': 'Welcome DE, '
  });