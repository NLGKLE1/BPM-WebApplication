define({
    'homepage-welcome': 'Welcome NL, '
  });