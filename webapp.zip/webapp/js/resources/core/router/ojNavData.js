  define(function () {

  const navData = [{
    "attr": {
      id: "login",
      name: "Login"
    },
    "attr": {
      id: "taskmanager",
      name: "Task Manager"
    },
    "attr": {
      id: "report",
      name: "Report"
    },
    "attr": {
      id: "about",
      name: "About"
    }
  }


  ];

  return navData;
});