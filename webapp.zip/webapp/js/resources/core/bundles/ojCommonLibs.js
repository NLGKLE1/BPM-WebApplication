define([
'ojs/ojarraydataprovider', 
'ojs/ojknockout', 
'ojs/ojmodule', 
'ojs/ojrouter', 
'ojs/ojmodule-element', 
'ojs/ojrouter', 
'ojs/ojarraytabledatasource',
'ojs/ojpagingtabledatasource',
'ojs/ojjsontreedatasource',
'ojs/ojmodule-element-utils',
'ojs/ojvalidation-number',
'ojs/ojvalidationgroup',
'promise', 
'text',
'ojLogger'
], function() {});
