/**
  Copyright (c) 2015, 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define({
  "root": {
    "ojet-errorloading" : {
    		"sampleString": "The strings file can be used to manage translatable resources"
    }
  }
});