/**
  Copyright (c) 2015, 2018, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
'use strict';
define(
    ['ojs/ojcore', 'knockout', 'jquery', 'ojL10n!./resources/nls/ojet-loading-strings', 'ojs/ojprogress'], function (oj, ko, $, componentStrings) {

    
    function OjetLoadingModel(context) {
    }

    return OjetLoadingModel;
});